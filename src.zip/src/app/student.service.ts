import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, Observable } from 'rxjs';
import { Student } from './student';

@Injectable({
  providedIn: 'root'
})
export class StudentService {

  constructor(private http : HttpClient) { }

  baseUrl = 'http://localhost:3000/students';  

  student : Student  = new Student();

  createStudent(student: Object): Observable<object> {  
    console.log("I am in" +student);
    return this.http.post(`${this.baseUrl}`, student);  
  }  

  getStudentList(): Observable<Student[]> {  
    return this.http.get<Student[]>(`${this.baseUrl}`)
    .pipe(
      catchError(this.errorHandler);
    )
  }



  errorHandler(errorHandler: any): import("rxjs").OperatorFunction<Student[], any> {
    throw new Error('Method not implemented.');
  }
}
